package fr.utt.LO02.projetLO02;

/**
 * Premi�re caract�ristique d'une carte
 * 
 * @author Corentin R�ault
 * @version 1.0
 * 
 * @see Card
 */

public enum CardType1 {
	CIRCLE,
	TRIANGLE,
	SQUARE
}
