package fr.utt.LO02.projetLO02;

/**
 * Deuxi�me caract�ristique d'une carte
 * 
 * @author Corentin R�ault
 * @version 1.0
 * 
 * @see Card
 */

public enum CardType2 {
	SOLID,
	HOLLOW
}
