package fr.utt.LO02.projetLO02;

/**
 * Enum�ration des diff�rents mode de jeu
 * 
 * @author Corentin R�ault
 * @version 1.0
 * 
 * @see Jeu
 * @see Jeu#setMode(int)
 */
public enum Mode {
	Classique,
	Avanc�,
	Personnalis�
}
