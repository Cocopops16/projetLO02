package fr.utt.LO02.projetLO02;

/**
 * Troisi�me caract�ristique d'une carte
 * 
 * @author Corentin R�ault
 * @version 1.0
 * 
 * @see Card
 */

public enum CardType3 {
	RED,
	GREEN,
	BLUE
}
